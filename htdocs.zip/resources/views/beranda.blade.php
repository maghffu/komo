@extends('layoute.app')
@section('konten')
	<h1>beranda</h1>
@endsection